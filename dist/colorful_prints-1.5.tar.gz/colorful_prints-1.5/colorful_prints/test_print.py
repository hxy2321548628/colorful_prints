class TestClass:
    def __str__(self):
        return "TestClass instance as string"

    def __repr__(self):
        return "TestClass instance as repr"
