"""
Author: hxy
Date: 2025/02/24
Description: 
TODO:
使用设计模式进行抽象，太多重复的代码了
"""

from .colorful_print import *



