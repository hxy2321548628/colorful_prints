# 一个颜色输出的库，print的增强版！

使用colorama库实现

效果如下：
![](./image.png)
