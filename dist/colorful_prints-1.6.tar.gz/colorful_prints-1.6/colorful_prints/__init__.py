"""
Version: 1.6

Author: hxy

Date: 2025/02/24

Description: 

- 修复了jupyter中使用强制换行的问题

TODO:
- 使用设计模式进行抽象，太多重复的代码了
"""

from .colorful_prints import *



