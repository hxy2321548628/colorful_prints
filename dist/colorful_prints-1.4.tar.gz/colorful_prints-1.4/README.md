# 一个颜色输出的库，print的增强版！

使用colorama库实现

效果如下：

![](./image.png)

下面时可以调用的所有函数

 `colorful_print`
 
 `yellow_print`
 
 `red_print`
 
 `green_print`
 
 `blue_print`
 
 `magenta_print`
 
 `cyan_print`
 
 `white_print`
 
 `black_print`
 
 `bright_red_print`
 
 `bright_green_print`
 
 `bright_blue_print`
 
 `bright_yellow_print`
 
 `bright_magenta_print`
 
 `bright_cyan_print`
 
 `bright_white_print`
 
 `dim_red_print`
 
 `dim_green_print`
 
 `dim_blue_print`
 
 `dim_yellow_print`
 
 `dim_magenta_print`
 
 `dim_cyan_print`
 
 `dim_white_print`
 
 `danger`
 
 `success`
 
 `info`
 
 `warning`


# upload log

`1.4` 打印函数修改，从`console`直接使用`rich.print`,支持flush

`1.3` 修复1.2 bug 和 `warning` bug

`1.2` 修改"info"和"warning"的颜色，在开发中debug更方便

`1.1` 调整目录结构

